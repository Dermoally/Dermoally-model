# Acne detection > 2023-06-02 11:28pm
https://universe.roboflow.com/bangkit-academy-rnfpg/acne-detection-g5vvz

Provided by a Roboflow user
License: CC BY 4.0

